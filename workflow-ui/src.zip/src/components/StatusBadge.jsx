function StatusBadge({ status }) {

    const colors = {
        COMPLETED: "#22C55E",
        RUNNING: "#F59E0B",
        FAILED: "#EF4444",
        PENDING: "#6B7280",
        STOPPED: "#c5bbbb"
    };

    return (
        <span
            style={{
                backgroundColor: colors[status] || "#6B7280",
                color: "white",
                padding: "6px 12px",
                borderRadius: "20px",
                fontSize: "13px",
                fontWeight: "bold"
            }}
        >
            {status}
        </span>
    );
}

export default StatusBadge;